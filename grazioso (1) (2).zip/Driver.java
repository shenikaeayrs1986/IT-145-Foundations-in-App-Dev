import java.util.ArrayList;
import java.util.Scanner;

public class Driver {
    private static ArrayList<Dog> dogList = new ArrayList<Dog>();
    private static ArrayList<Monkey> monkeyList = new ArrayList<Monkey>();


    public static void main(String[] args) {displayMenu();
    Scanner input = new Scanner(System.in);
    char menu_choice;
        initializeDogList();
        initializeMonkeyList();
do {
	displayMenu();
	menu_choice = input.next().charAt(0);
	
  if (menu_choice == '1') { intakeNewDog (input);
        }
        else if (menu_choice == '2') { intakeNewMonkey(input);
        }
        else if (menu_choice == '3') { reserveAnimal(input);
        }
        else if (menu_choice == '4') {printAnimals(menu_choice);
        }
        else if (menu_choice == '5') { printAnimals(menu_choice);
        }
        else if (menu_choice == '6') { printAnimals(menu_choice);
        }
        else if (menu_choice == 'q') {
        	System.out.print("Quit application");
        	break;
        }
        else{
        	System.out.print("Error please enter valid input");
        }
        }
        

    while (menu_choice != 'q');
    }
   
	// This method prints the menu options
    public static void displayMenu() {
        System.out.println("\n\n");
        System.out.println("\t\t\t\tRescue Animal System Menu");
        System.out.println("[1] Intake a new dog");
        System.out.println("[2] Intake a new monkey");
        System.out.println("[3] Reserve an animal");
        System.out.println("[4] Print a list of all dogs");
        System.out.println("[5] Print a list of all monkeys");
        System.out.println("[6] Print a list of all animals that are not reserved");
        System.out.println("[q] Quit application");
        System.out.println();
        System.out.println("Enter a menu selection");
    }


    // Adds dogs to a list for testing
    public static void initializeDogList() {
        Dog dog1 = new Dog("Spot", "German Shepherd", "male", "1", "25.6", "05-12-2019", "United States", "intake", false, "United States");
        Dog dog2 = new Dog("Rex", "Great Dane", "male", "3", "35.2", "02-03-2020", "United States", "Phase I", false, "United States");
        Dog dog3 = new Dog("Bella", "Chihuahua", "female", "4", "25.6", "12-12-2019", "Canada", "in service", true, "Canada");

        dogList.add(dog1);
        dogList.add(dog2);
        dogList.add(dog3);
    }


    // Adds monkeys to a list for testing
    //Optional for testing
    public static void initializeMonkeyList() {
    	Monkey monkey1 = new Monkey("Ramon", "male", "4", "25.6", "12-12-2019", "United States", "in service", false, "United States", "Capuchin", "10.4", "15.6", "16.4");
    	Monkey monkey2 = new Monkey("Norma", "female", "3", "15.6", "11-11-2011", "United States", "Phase 4", true, "United States", "Guenon", "15", "20.2", "16.8");
    	Monkey monkey3 = new Monkey("Sonny", "female", "2", "25.7", "12-13-2022", "Canada", "in service", true, "Canada", "Macaque", "16", "21.4", "15.5");
    	
    	monkeyList.add(monkey1);
    	monkeyList.add(monkey2);
    	monkeyList.add(monkey3);
    }


    // Complete the intakeNewDog method
    // The input validation to check that the dog is not already in the list
    // is done for you
    public static void intakeNewDog(Scanner scanner) {
        System.out.println("What is the dog's name?");
        String name = scanner.nextLine();
        for(Dog dog: dogList) {
            if(dog.getName().equalsIgnoreCase(name)) {
                System.out.println("\n\nThis dog is already in our system\n\n");
                return; //returns to menu
            }
            
        }
System.out.println("Please confirm your Dog's Gender.");
String gender = scanner.nextLine();
System.out.println("Please confirm your Dog's Breed.");
String breed = scanner.nextLine();
System.out.println("Please confirm your Dog's age.");
String age = scanner.nextLine();
System.out.println("Please confirm your Dog's weight.");
String weight = scanner.nextLine();
System.out.println("Please confirm your Dog's training status.");
String trainingStatus = scanner.nextLine();
System.out.println("Please confirm your Dog's Service Country.");
String inServiceCountry = scanner.nextLine();
System.out.println("Please confirm if your Dog is reserved.");
boolean reserved = scanner.nextBoolean();
System.out.println("Please confirm your Dog's Acquistion Country.");
String acquisitionCountry = scanner.nextLine();
System.out.println("Please confirm your Dog's Acquistion Date.");
String acquisitionDate = scanner.nextLine();
        // Add the code to instantiate a new dog and add it to the appropriate list
Dog dog4 = new Dog (name, gender, age, breed, weight, trainingStatus, acquisitionCountry, acquisitionDate,reserved, inServiceCountry);
dogList.add(dog4);
System.out.println("Your addition has been processed successfully.");
    }
    
  // intake new monkey method
    public static void intakeNewMonkey(Scanner scanner) {
        System.out.println("What is the Monkey's name?");
        System.out.println("What is the Monkey's species?");
        String name = scanner.nextLine();
        String species = scanner.nextLine();
        for(Monkey monkey: monkeyList) {
            if(monkey.getName().equalsIgnoreCase(name)) {
                System.out.println("\n\nThis monkey is already in our system\n\n");}
            if (monkey.getSpecies().equalsIgnoreCase(species)) {
            	System.out.println("\n\nTank you for confirming your Monkey's species\n\n");
            }
                return; 
            }
        
System.out.println("Please confirm your Monkey's Gender.");
String gender = scanner.nextLine();
System.out.println("Please confirm your Monkey's age.");
String age = scanner.nextLine();
System.out.println("Please confirm your Monkey's weight.");
String weight = scanner.nextLine();
System.out.println("Please confirm your Monkey's training status.");
String trainingStatus = scanner.nextLine();
System.out.println("Please confirm your Monkey's Service Country.");
String inServiceCountry = scanner.nextLine();
System.out.println("Please confirm if your Monkey is reserved.");
boolean reserved = scanner.nextBoolean();
System.out.println("Please confirm your Monkey's Acquistion Country.");
String acquisitionCountry = scanner.nextLine();
System.out.println("Please confirm your Monkey's Acquistion Date.");
String acquisitionDate = scanner.nextLine();
System.out.println("Please confirm your Monkey's Acquistion Date.");
String tailLength = scanner.nextLine();
System.out.println("Please confirm your Monkey's Acquistion Date.");
String height = scanner.nextLine();
System.out.println("Please confirm your Monkey's Acquistion Date.");
String bodyLength = scanner.nextLine();
     
Monkey monkey4 = new Monkey(name, gender, species, age, weight, trainingStatus, inServiceCountry, reserved, acquisitionCountry, acquisitionDate, tailLength, height, bodyLength);
monkeyList.add(monkey4);
System.out.println("Your addition has been processed successfully.");
    }

        public static void reserveAnimal(Scanner scanner) {
        	scanner.nextLine();
            System.out.println("The method reserveAnimal needs to be implemented");
            System.out.println("Please confirm your Animal Type.");
            String animalType = scanner.nextLine();
            if (animalType.equalsIgnoreCase("monkey")) {
            	System.out.println("Please confirm your Monkey's Acquisition Country.");
            	String country = scanner.nextLine();
            	for (Monkey obj: monkeyList) {
            		if (obj.getAcquisitionLocation().equalsIgnoreCase(country)) {
            			obj.setReserved(true);
            			System.out.println("Your reservation has been processed successfully");
            			return;
            		}
            	}
            	System.out.println("Your Monkey's record cannot be found.");
            }
    else if (animalType.equalsIgnoreCase("dog"))
    {
    	System.out.println("Please confirm your Dog's Acquisition Country.");
    	String country = scanner.nextLine();
    	for (Dog obj: dogList) {
    		if (obj.getAcquisitionLocation().equalsIgnoreCase(country)) {
    			obj.setReserved(true);
    			System.out.println("Your reservation has been processed successfully");
    			return;
    		}
		}
	System.out.println("Your Dog's record cannot be found.");
        }
else { System.out.println("Error unable to locate animal type.");
}
        }

        public static void printAnimals(char menu_choice) {
            System.out.println("The method printAnimals needs to be implemented");
if (menu_choice == '4') {
	System.out.println(dogList);
        }
else if (menu_choice == '5') {
	System.out.println(monkeyList);
}
else if (menu_choice == '6') {
	for (int i = 0; i < dogList.size(); i++) {
		if (dogList.get(i).getTrainingStatus().equals("in service")&& dogList.get(i).getReserved()==false) {
			System.out.println(dogList.get(i));
		}
	}
	for (int i = 0; i < monkeyList.size(); i++) {
		if (monkeyList.get(i).getTrainingStatus().equals("in service")&& monkeyList.get(i).getReserved()==false) {
			System.out.println(monkeyList.get(i));
		}
        
	}
}
        }
}
