
// inherit from RescueAnimal and implement attributes
public class Monkey extends RescueAnimal{
	private String tailLength;
	private String height;
	private String bodyLength;
	private String species;
	

	enum Species{Capuchin, Guenon, Macaque, Marmoset, SquirrelMonkey, Tamarin;}
	public static void main(String[]args) {
	}
	
	public Monkey() {
		tailLength = "";
		height = "";
		bodyLength = "";
		species = "";
	}
// Constructors, Accessors and Mutators
	public Monkey (String name, String gender, String species, String age, String weight, String trainingStatus,
			String inServiceCountry, boolean reserved, String acquisitionCountry, String acquisitionDate, String tailLength, String height,
			String bodyLength) {
		this.tailLength = tailLength;
		this.height = height;
		this.bodyLength = bodyLength;
		this.species = species;
		this.getWeight();
		this.setAcquisitionCountry(acquisitionCountry);
		this.getAcquisitionDate();
		this.getTrainingStatus();
		this.getReserved();
		this.getTrainingStatus();
		this.getAge();
		this.getGender();
		this.setAcquisitionDate(acquisitionDate);
		this.setAge(age);
		this.setGender(gender);
		this.setTrainingStatus(trainingStatus);
		this.setReserved(reserved);
		this.setWeight(weight);
	}

	String getTailLength() { 
		return tailLength;
	}
	String getHeight() {
		return height;
	}
	String getBodyLength() {
		return bodyLength;}
	String getSpecies() {
		return species;}
	void setTailLength(String TailLength) {
		this.tailLength = TailLength;}
	void setHeight (String Height) {
		this.height = Height;}
	void setBodyLength(String BodyLength) {
		this.bodyLength = BodyLength;}
	void setSpecies(String Species) {
		this.species = Species;}
	
	
}
